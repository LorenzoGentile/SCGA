# dim=2
# obj <- smoof::makeSphereFunction(dim)
#
# OUT <- SCGA(control=list(size=4,maxEvaluations=100,Fun=obj,feature=CreateFeature(list(lower=rep(0,dim),upper=rep(1,dim))),
#                          vectorOnly=T,elitism=1,seed=1,backup=F,backupInterval=1,saveAll=T,printIter=T))
# # con = createControl(list(size=6,maxEvaluations=4000))
