obj <- smoof::makeSphereFunction(20)
result <- SCGA(control=list(
  size=10,
  maxEvaluations=4000,
  Fun=airfoilOptObjVec,
  feature=CreateFeature(list(lower=rep(-5,20),upper=rep(5,20))),
  elitism=1,
  mutRate=.01,
  crossPerc=.1,
  mutPerc=.1,
  vectorOnly=F,
  vectorized=T
  ))
